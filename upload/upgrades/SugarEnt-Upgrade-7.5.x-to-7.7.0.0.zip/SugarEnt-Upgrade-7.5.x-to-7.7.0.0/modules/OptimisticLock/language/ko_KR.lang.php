<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
   'LBL_YOURS' => '귀하의 소유',
   'LBL_IN_DATABASE' => '데이타베이스',
   'LBL_CONFLICT_EXISTS' => '대립이 존재합니다.',
   'LBL_ACCEPT_DATABASE' => '데이타베이스 수락합니다.',
   'LBL_ACCEPT_YOURS' => '귀하의 소유를 수락합니다.',
   'LBL_RECORDS_MATCH' => '기록일치',
   'LBL_NO_LOCKED_OBJECTS' => '고정된 물건이 없습니다.',
   
);

?>